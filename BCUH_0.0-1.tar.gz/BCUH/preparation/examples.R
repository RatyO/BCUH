# For development
library(devtools)
library(packagedocs)
library(Rdpack)

#Testing the class structure
library(lubridate)
library(BCUH)

data("station_Jyvaskyla")
data("ALADIN_Jyvaskyla")

ctrl <- c(1971,2000)
scen <- c(2071,2100)

ind.obs <- which(month(station_Jyvaskyla$date) == 12 &
                   year(station_Jyvaskyla$date) %in% seq(ctrl[1],ctrl[2]))
ind.ctrl <- which(month(ALADIN_Jyvaskyla$date) == 12 &
                    year(ALADIN_Jyvaskyla$date) %in% seq(ctrl[1],ctrl[2]))
ind.scen <- which(month(ALADIN_Jyvaskyla$date) == 12 &
                    year(ALADIN_Jyvaskyla$date) %in% seq(scen[1],scen[2]))
  
obs.ctrl <- station_Jyvaskyla[ind.obs,2:3]
rcm.ctrl <- ALADIN_Jyvaskyla[ind.ctrl,2:3]
rcm.scen <- ALADIN_Jyvaskyla[ind.scen,2:3]

test <- biasco2D(obs.ctrl,rcm.ctrl,rcm.scen, names = c("tas", "pr"), cond="T")

par(mfrow=c(1,2))

plot(obs.ctrl)
points(rcm.ctrl,col="red")
legend("topleft",c("Obs","Ctrl"),col=c("black","red"),pch=c(1,1))

plot(dat(adj(test)))
points(rcm.scen,col="red")
legend("topleft",c("Adj","Scen"),col=c("black","red"),pch=c(1,1))

obs <- TS_2D(data = obs.ctrl, names = c("tas", "pr"))
ctrl <- TS_2D(data = rcm.ctrl, names = c("tas", "pr"))
scen <- TS_2D(data = rcm.scen, names = c("tas", "pr"))

test <- biasco2D(obs,ctrl,scen, names = c("tas", "pr"))


tt <- BC.joint(obs=obs,ctrl=ctrl,scen=scen)
tt <- .JBC(tt,cond="P",threshold=0.1)
test  <- as(tt,"BiascoTimeSeriesTP")

dc.object <- biasco(obs.ctrl$tas, rcm.ctrl$tas, rcm.scen$tas, type = "abs", method = "M1")
bc.object <- biasco(obs.ctrl$tas, rcm.ctrl$tas, rcm.scen$tas, type = "abs", method = "M6")

plot(quantile(dat(adj(bc.object)),seq(0,1,0.01)),type="l",
     main="Quantile plot", xlab="%", ylab="Celcius",ylim=c(-30,10))
lines(quantile(dat(adj(dc.object)),seq(0,1,0.01)),lty=2)
lines(quantile(obs.ctrl$tas,seq(0,1,0.01)),col="red")
lines(quantile(rcm.ctrl$tas,seq(0,1,0.01)),col="blue")
lines(quantile(rcm.scen$tas,seq(0,1,0.01)),col="blue",lty=2)
legend("topleft", c("M1","M6","Obs","Ctrl","Scen"),
       col=c("black","black","red","blue","blue"),lty=c(1,2,1,1,2))

obs <- TS(obs.ctrl[,1], type = type)
ctrl <- TS(rcm.ctrl[,1], type = type)
scen <- TS(rcm.scen[,1], type = type)

# plot(quantile(obs.ctrl[,1],seq(0,1,0.001),na.rm=T))
# lines(quantile(rcm.ctrl[,1],seq(0,1,0.001),na.rm=T),col="red")
# lines(quantile(rcm.scen[,1],seq(0,1,0.001),na.rm=T),col="blue")
# legend("topleft", legend = c("Obs","Ctrl","Scen"), col=c("black","red","blue"),lty=1)

bc <- BC()
bc.abs <- BC.abs(obs = obs, ctrl = ctrl, scen = scen)
bc.out <- biasco(obs, ctrl, scen, type = "abs", method = "M1")

biasco(obs.ctrl[,1], ctrl[,1], scen[,1], type = "abs", method = "M1")

bc.abs <- BC.abs(adj = adjj, obs = obs, ctrl = ctrl, scen = scen)
bc.abs <- BC.abs()

bc.abs1 <- .BcMean(bc.abs)
bc.abs2 <- .BcMeanSd(bc.abs)
bc.abs3 <- .BcMeanSdSkew(bc.abs)
bc.abs4 <- .BcQmParam(bc.abs,fit.type="linear")
bc.abs5 <- .BcQmEmpir(bc.abs, smooth = 0.05)

bc.abs6 <- .DcMean(bc.abs)
bc.abs7 <- .DcMeanSd(bc.abs)
bc.abs8 <- .DcMeanSdSkew(bc.abs)
bc.abs9 <- .DcQmParam(bc.abs,fit.type="normal")
bc.abs10 <- .DcQmEmpir(bc.abs, smooth = 0.05)

qs <- seq(0,1,1/100)
plot(quantile(obs.ctrl[,1],qs))
lines(quantile(rcm.ctrl[,1],qs),type = "l", lty=2)
lines(quantile(rcm.scen[,1],qs),type = "l", lty=3)

print(c(mean(data(obs)),mean(data(adj(bc.abs1)))))
type(object = )
lines(quantile(data(adj(bc.abs1)),qs),col="red")
lines(quantile(data(adj(bc.abs2)),qs),col="red")
lines(quantile(data(adj(bc.abs3)),qs),col="red")
lines(quantile(data(adj(bc.abs4)),qs),col="red")
lines(quantile(data(adj(bc.abs5)),qs),col="red")

lines(quantile(data(adj(bc.abs6)),qs),col="blue")
lines(quantile(data(adj(bc.abs7)),qs),col="blue")
lines(quantile(data(adj(bc.abs8)),qs),col="blue")
lines(quantile(data(adj(bc.abs9)),qs),col="blue")
lines(quantile(data(adj(bc.abs10)),qs),col="blue")

#Test ratio correction methods
obs <- TS(data = obs.ctrl[,2], nvar = 1)
ctrl <- TS(data = rcm.ctrl[,2], nvar = 1)
scen <- TS(data = rcm.scen[,2], nvar = 1)
adjj <- TS(data = NA, nvar = 1)

bc.ratio <- .BC.ratio(adj = adjj, obs = obs, ctrl = ctrl, scen = scen)
bc.ratio1 <- DC.mean(bc.ratio)
bc.ratio2 <- DC.mean.sd1(bc.ratio)
bc.ratio3 <- DC.mean.sd2(bc.ratio)
#bc.ratio4 <- DC.qm.param(bc.ratio,fit.type="normal")
bc.ratio5 <- DC.qm.empir(bc.ratio, smooth = 0.0, pre.adj = F, post.adj = F)

bc.ratio6 <- BC.mean(bc.ratio)
bc.ratio7 <- BC.mean.sd1(bc.ratio)
bc.ratio8 <- BC.mean.sd2(bc.ratio)
bc.ratio9 <- BC.qm.param(bc.ratio,threshold=0.1)
bc.ratio10 <- BC.qm.empir(bc.ratio, smooth = 0.0, pre.adj = F, post.adj = F)

qs <- seq(0,1,1/100)
plot(quantile(obs.ctrl[,2],qs))
lines(quantile(rcm.ctrl[,2],qs),type = "l", lty=2)
lines(quantile(rcm.scen[,2],qs),type = "l", lty=3)

lines(quantile(data(adj(bc.ratio1)),qs),col="red")
lines(quantile(data(adj(bc.ratio2)),qs),col="red")
lines(quantile(data(adj(bc.ratio3)),qs),col="red")
#lines(quantile(data(adj(bc.ratio4)),qs),col="red")
lines(quantile(data(adj(bc.ratio5)),qs),col="red")

lines(quantile(data(adj(bc.ratio6)),qs),col="blue")
lines(quantile(data(adj(bc.ratio7)),qs),col="blue")
lines(quantile(data(adj(bc.ratio8)),qs),col="blue")
lines(quantile(data(adj(bc.ratio9)),qs),col="blue")
lines(quantile(data(adj(bc.ratio10)),qs),col="blue")

#Joint bias correction with the JBC algorithm

obs <- TS_2D(data = obs.ctrl, names = c("tas", "pr"))
ctrl <- TS_2D(data = rcm.ctrl, names = c("tas", "pr"))
scen <- TS_2D(data = rcm.scen, names = c("tas", "pr"))
adjj <- TS_2D()

bc.joint <- .BC.joint(obs = obs, ctrl = ctrl, scen = ctrl)
bc.tp <- .JBC(bc.joint, cond="P", threshold=0.1)

plot(quantile(obs.ctrl[,1],qs))
lines(quantile(rcm.ctrl[,1],qs),col="red")
#lines(quantile(rcm.scen[,1],qs),col="green")
lines(quantile(data(adj(bc.tp))[,1],qs),col="blue")

plot(quantile(obs.ctrl[,2],qs))
lines(quantile(rcm.ctrl[,2],qs),col="red")
#lines(quantile(rcm.scen[,2],qs),col="green")
lines(quantile(data(adj(bc.tp))[,2],qs),col="blue")

library(copula)
source("../verScores//R/IO_verScores.r")


puv <- getCopulaNodes(n=20)
probs <- unique(puv[,1])
cdfbreaks <- seq(0,1,0.1)
pdfbreaks <- c(seq(0,2.8,0.2))
par(mfrow=c(2,2))
par(oma=c(6,6,2,7))
par(mar=c(0,0,0,0))
par(cex.axis=1.1)
par(cex.lab=1.1)
par(mgp=c(2.2,0.7,0))
par(xpd=FALSE)
nNodes <- 20

u <- pobs(data(adj(bc.tp))[data(adj(bc.tp))[,2]>0,1])
v <- pobs(data(adj(bc.tp))[data(adj(bc.tp))[,2]>0,2])
v.o <- pobs(data(obs)[data(obs)[,2]>0,2])
u.o <- pobs(data(obs)[data(obs)[,2]>0,1])
v.o <- pobs(data(obs)[data(obs)[,2]>0,2])
u.c <- pobs(data(ctrl)[data(ctrl)[,2]>0,1])
v.c <- pobs(data(ctrl)[data(ctrl)[,2]>0,2])
u.s <- pobs(data(scen)[data(scen)[,2]>0,1])
v.s <- pobs(data(scen)[data(scen)[,2]>0,2])

copula.o <- beta.kernel.copula.surface(u,v,0.05,0.05,nNodes)
copula.o <- beta.kernel.copula.surface(u.o,v.o,0.05,0.05,nNodes)
copula.c <- beta.kernel.copula.surface(u.c,v.c,0.05,0.05,nNodes)
copula.s <- beta.kernel.copula.surface(u.s,v.s,0.05,0.05,nNodes)

image(copula.o$x,copula.o$y,copula.o$z,ylab="F(P)",xlab="F(T)",main="copula pdf obs",cex.main=1.5,cex.lab=1.4,cex.axis=1.5,breaks=seq(0,2,0.1),
      col=rev(heat.colors(length(seq(0,2,0.1))-1)))
image(copula.c$x,copula.c$y,copula.c$z,ylab="F(P)",xlab="F(T)",main="Empirical Copula",cex.main=1.5,cex.lab=1.4,cex.axis=1.5,breaks=seq(0,2,0.1),
      col=rev(heat.colors(length(seq(0,2,0.1))-1)))
image(copula.s$x,copula.s$y,copula.s$z,ylab="F(P)",xlab="F(T)",main="Empirical Copula",cex.main=1.5,cex.lab=1.4,cex.axis=1.5,breaks=seq(0,2,0.1),
      col=rev(heat.colors(length(seq(0,2,0.1))-1)))
image(copula$x,copula$y,copula$z,ylab="F(P)",xlab="F(T)",main="Empirical Copula",cex.main=1.5,cex.lab=1.4,cex.axis=1.5,breaks=seq(0,2,0.1),
             col=rev(heat.colors(length(seq(0,2,0.1))-1)))
