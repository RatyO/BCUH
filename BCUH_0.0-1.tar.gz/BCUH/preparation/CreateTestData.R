#Create test data for the BIASCO package
library(splancs)
great.circ.dist <- function (long1, lat1, long2, lat2)
{
  rad <- pi/180
  a1 <- lat1 * rad
  a2 <- long1 * rad
  b1 <- lat2 * rad
  b2 <- long2 * rad
  dlon <- b2 - a2
  dlat <- b1 - a1
  a <- (sin(dlat/2))^2 + cos(a1) * cos(b1) * (sin(dlon/2))^2
  c <- 2 * atan2(sqrt(a), sqrt(1 - a))
  R <- 6378.145
  d <- R * c
  return(d)
}

createOutputDates <- function(y1,y2,by="day"){
  start <- as.Date(paste(y1,"-01-01",sep=""),format="%Y-%m-%d")
  end <- as.Date(paste(y2,"-12-31",sep=""),format="%Y-%m-%d")
  dates <- seq.Date(start,end,by = by)
  output <- as.POSIXlt(dates)
  return(output)
}

tas <- read.table("/homeappl/home/oraty/appl_taito/R/BCUH/preparation/tas_Jyvaskyla_62.40N_25.68E_139m_1951-2017.txt",skip=2,header=T)
pr <- read.table("/homeappl/home/oraty/appl_taito/R/BCUH/preparation/pr_Jyvaskyla_62.40N_25.68E_139m_1951-2017.txt",skip=2,header=T)
dates.tas <- as.Date(with(tas, paste(Year, m, d,sep="-")), "%Y-%m-%d")
dates.pr <- as.Date(with(pr, paste(Year, m, d,sep="-")), "%Y-%m-%d")

missing.tas <- which(diff(dates.tas)>1)
missing.pr <- which(diff(dates.pr)>1)

tas.data <- tas$Temperature.Celcius.
if(length(missing.tas)!= 0){
  dates.tas <- append(dates.tas,as.Date(dates.tas[missing.tas]+1),missing.tas)
  tas.data <- append(tas$Temperature.Celcius.,NA,missing.tas)
}

pr.data <- pr$Precipitation.mm.d.
if(length(missing.pr)!= 0){
  dates.pr <- append(dates.pr,as.Date(dates.pr[missing.pr]+1),missing.pr)
  pr.data <- append(pr$Precipitation.mm.d.,NA,missing.pr)
}

station_Jyvaskyla <- output <- data.frame(date=dates.tas,tas=tas.data,pr=pr.data)
rownames(output) <- seq(1:length(dates.tas))

path = "/home/oraty/appl_taito/R/BCUH/data/"
output.name <- "station_Jyvaskyla_1951-2017"
name <- "Jyvaskyla_1951-2017"
save(output,output.name, file = paste(path,name,sep=""))

#Load GCM-RCM data
require(ncdf4)

station.lon <- 25.68
station.lat <- 62.40

id <- nc_open("/wrk/oraty/DONOTREMOVE/CORDEX_0.11/ALADIN/biasco_domain/RCP45/tas/ALADIN_biasco_domain_RCP45_1950-2100_tas.nc")
lat <- ncvar_get(id,"lat")
lon <- ncvar_get(id,"lon")
time <- ncvar_get(id,"time")

lon2 <- rep(lon,each=length(lat))
lat2 <- rep(lat,length(lon))

dist <- spDistsN1(cbind(lon2,lat2),cbind(station.lon,station.lat))
lon.ind <- which(lon == lon2[which(dist == min(dist))])
lat.ind <- which(lat == lat2[which(dist == min(dist))])

rcm.tas <- ncvar_get(id, "tas", start=c(lon.ind, lat.ind, 1), count = c(1,1,length(time)))
nc_close(id)

id <- nc_open("/wrk/oraty/DONOTREMOVE/CORDEX_0.11/ALADIN/biasco_domain/RCP45/pr/ALADIN_biasco_domain_RCP45_1950-2100_pr.nc")
lat <- ncvar_get(id,"lat")
lon <- ncvar_get(id,"lon")
time <- ncvar_get(id,"time")

lon2 <- rep(lon,each=length(lat))
lat2 <- rep(lat,length(lon))

dist <- spDistsN1(cbind(lon2,lat2),cbind(station.lon,station.lat))
lon.ind <- which(lon == lon2[which(dist == min(dist))])
lat.ind <- which(lat == lat2[which(dist == min(dist))])

rcm.pr <- ncvar_get(id, "pr", start=c(lon.ind, lat.ind, 1), count = c(1,1,length(time)))
rcm.pr[rcm.pr < 0] <- 0

ref.date <- as.Date(paste("1949-12-01"),format="%Y-%m-%d")
start <- ref.date + time[1]
end <- ref.date + tail(time,1)
dates <- createOutputDates(start,end)

ALADIN_Jyvaskyla <- rcm.data <- data.frame(date = dates,tas = rcm.tas, pr = rcm.pr)
name <- name.output <- "ALADIN_Jyvaskyla_tp_1950-2100"
path = "/home/oraty/appl_taito/R/BCUH/data/"
save(rcm.data, name.output, file = paste(path,name,sep=""))
