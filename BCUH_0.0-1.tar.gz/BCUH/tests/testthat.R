#Test that TimeSeries objects have proper slot values

test_that("Object is of right type" ){
  expect_that(typeof(TS()))
}
