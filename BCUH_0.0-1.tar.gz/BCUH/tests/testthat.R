library(testthat)
library(BCUH)

test_check("BCUH")
